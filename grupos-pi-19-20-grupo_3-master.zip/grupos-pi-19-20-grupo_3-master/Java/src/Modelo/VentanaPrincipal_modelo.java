package Modelo;

public class VentanaPrincipal_modelo {

	public VentanaPrincipal_modelo() {}
}
