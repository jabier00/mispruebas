# -*- coding: utf-8 -*-
"""
Created on Sat March 28 19:07:05 2020

########################
## Versión: 0.1.0 
########################
Date: 28/03/2020

########################
## Packages: 
########################
Packages Versión: X.X.X.rc1            

########################
## Libraries: 
########################
Libraries Versión: X.X.X.rc1            

########################
## @author: Team 3
########################
→ DAVID LOZANO CANTARERO
→ ROBERTO SÁNCHEZ KEILHAUER
→ JAVIER LIÉBANA CASTRO
→ DANIEL SANTIAGO SAINERO
→ JAVIER DOMINGUEZ ANDRES

########################
## About
########################
Teacher:  Javier Sanchez Soriano < javier.sanchez@universidadeuropea.es>
Subject: Copyright © UEM ® | Proyecto de Ingeniería I

"""
